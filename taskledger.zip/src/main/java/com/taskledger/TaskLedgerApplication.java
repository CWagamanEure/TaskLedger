package com.taskledger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskLedgerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskLedgerApplication.class, args);
	}

}
